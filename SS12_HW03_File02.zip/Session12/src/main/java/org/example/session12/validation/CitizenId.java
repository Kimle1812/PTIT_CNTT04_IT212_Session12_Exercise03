package org.example.session12.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

/**
 * Custom Validation Annotation dùng để xác thực Số định danh cá nhân (CCCD) Việt Nam.
 * CCCD hợp lệ phải chứa đúng 12 chữ số.
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
@Documented
@Constraint(validatedBy = CitizenIdValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface CitizenId {
    String message() default "Số định danh cá nhân (CCCD) phải gồm đúng 12 chữ số và thuộc định dạng hợp lệ";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
