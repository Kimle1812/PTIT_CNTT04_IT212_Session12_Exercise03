package org.example.session12.repository;

import org.example.session12.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Lớp truy xuất cơ sở dữ liệu cho thực thể Account.
 * Sử dụng thư viện Spring Data JPA để tự động sinh các truy vấn SQL.
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {

    /**
     * Tìm kiếm tài khoản theo số Căn cước công dân.
     *
     * @param citizenId số CCCD cần tìm
     * @return Optional chứa đối tượng Account nếu có
     */
    Optional<Account> findByCitizenId(String citizenId);

    /**
     * Kiểm tra sự tồn tại của số CCCD trong hệ thống.
     *
     * @param citizenId số CCCD cần kiểm tra
     * @return true nếu số CCCD đã tồn tại, ngược lại false
     */
    boolean existsByCitizenId(String citizenId);

    /**
     * Kiểm tra sự tồn tại của số điện thoại đăng ký trong hệ thống.
     *
     * @param phone số điện thoại cần kiểm tra
     * @return true nếu số điện thoại đã tồn tại, ngược lại false
     */
    boolean existsByPhone(String phone);

    /**
     * Kiểm tra sự tồn tại của email đăng ký trong hệ thống.
     *
     * @param email email cần kiểm tra
     * @return true nếu email đã tồn tại, ngược lại false
     */
    boolean existsByEmail(String email);

    /**
     * Kiểm tra sự tồn tại của số tài khoản trong hệ thống.
     * Dùng để đảm bảo không sinh trùng số tài khoản ngẫu nhiên.
     *
     * @param accountNumber số tài khoản cần kiểm tra
     * @return true nếu đã tồn tại, ngược lại false
     */
    boolean existsByAccountNumber(String accountNumber);
}
