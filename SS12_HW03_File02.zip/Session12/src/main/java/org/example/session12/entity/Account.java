package org.example.session12.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Thực thể đại diện cho thông tin tài khoản của khách hàng tại ABC Bank.
 * Áp dụng các annotation của JPA để tự động sinh schema cơ sở dữ liệu.
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
@Entity
@Table(name = "accounts", indexes = {
    @Index(name = "idx_citizen_id", columnList = "citizen_id", unique = true),
    @Index(name = "idx_account_number", columnList = "account_number", unique = true)
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Account {

    /**
     * Khóa chính tự động tăng của cơ sở dữ liệu.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Mã định danh tài khoản duy nhất (UUID), dùng để giao tiếp qua API (độ bảo mật cao hơn lộ ID tự tăng).
     */
    @Column(name = "account_id", nullable = false, unique = true, length = 36)
    private String accountId;

    /**
     * Họ và tên đầy đủ của khách hàng.
     */
    @Column(name = "full_name", nullable = false, length = 100)
    private String fullName;

    /**
     * Số điện thoại đăng ký (Dùng làm Username đăng nhập Digital Banking).
     */
    @Column(name = "phone", nullable = false, unique = true, length = 15)
    private String phone;

    /**
     * Địa chỉ Email cá nhân.
     */
    @Column(name = "email", nullable = false, unique = true, length = 100)
    private String email;

    /**
     * Số Căn cước công dân (12 chữ số).
     */
    @Column(name = "citizen_id", nullable = false, unique = true, length = 12)
    private String citizenId;

    /**
     * Số tài khoản ngân hàng sinh tự động.
     */
    @Column(name = "account_number", nullable = false, unique = true, length = 20)
    private String accountNumber;

    /**
     * Trạng thái tài khoản (PENDING: Chờ eKYC, ACTIVE: Đã kích hoạt).
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private AccountStatus status;

    /**
     * Thời gian khởi tạo tài khoản.
     */
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    /**
     * Phương thức callback trước khi lưu mới thực thể vào database.
     * Tự động sinh accountId ngẫu nhiên và gán thời gian tạo.
     */
    @PrePersist
    protected void onCreate() {
        if (this.accountId == null) {
            this.accountId = UUID.randomUUID().toString();
        }
        this.createdAt = LocalDateTime.now();
    }
}
