package org.example.session12.entity;

/**
 * Danh sách các trạng thái của tài khoản eKYC.
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
public enum AccountStatus {
    /**
     * Tài khoản mới đăng ký thông tin cơ bản, chờ thực hiện eKYC (OCR & Liveness).
     */
    PENDING,

    /**
     * Tài khoản đã hoàn thành eKYC trực tuyến thành công, sẵn sàng giao dịch.
     */
    ACTIVE
}
