package org.example.session12.service;

import org.example.session12.dto.AccountRegisterRequest;
import org.example.session12.dto.AccountRegisterResponse;

/**
 * Interface định nghĩa các nghiệp vụ liên quan đến quản lý tài khoản khách hàng.
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
public interface AccountService {

    /**
     * Thực hiện đăng ký mở tài khoản cơ bản.
     * Kiểm tra tính trùng lặp của thông tin và khởi tạo số tài khoản trong hệ thống.
     *
     * @param request thông tin đăng ký gửi từ client
     * @return kết quả đăng ký tài khoản (ID, số tài khoản, trạng thái)
     */
    AccountRegisterResponse registerBasicAccount(AccountRegisterRequest request);
}
