package org.example.session12.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Cấu hình bảo mật Spring Security cho ứng dụng.
 * Cho phép truy cập không cần xác thực vào cổng đăng ký eKYC công khai.
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    /**
     * Cấu hình chuỗi lọc bảo mật (Security Filter Chain).
     * Tắt CSRF cho các API RESTful và cấu hình quyền truy cập.
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // Tắt bảo vệ CSRF vì API sử dụng mô hình RESTful Stateless với JWT (nếu có sau này)
            .csrf(AbstractHttpConfigurer::disable)
            
            // Định nghĩa phân quyền truy cập endpoint
            .authorizeHttpRequests(auth -> auth
                // Cho phép tất cả các yêu cầu gửi đến API đăng ký mở tài khoản cơ bản
                .requestMatchers("/api/v1/accounts/register").permitAll()
                // Mọi yêu cầu khác đều yêu cầu phải được xác thực trước
                .anyRequest().authenticated()
            );

        return http.build();
    }
}
