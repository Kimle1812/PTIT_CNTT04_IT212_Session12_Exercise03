package org.example.session12.exception;

/**
 * Ngoại lệ tùy chỉnh ném ra khi phát hiện tài nguyên đăng ký bị trùng lặp trong hệ thống (SĐT, Email, CCCD).
 * Được bắt và xử lý bởi GlobalExceptionHandler để trả về mã lỗi HTTP 409 Conflict.
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
public class DuplicateResourceException extends RuntimeException {

    public DuplicateResourceException(String message) {
        super(message);
    }
}
