package org.example.session12.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.session12.dto.AccountRegisterRequest;
import org.example.session12.dto.AccountRegisterResponse;
import org.example.session12.service.AccountService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller cung cấp các API liên quan đến quản lý tài khoản người dùng.
 * Endpoint chính thức: /api/v1/accounts
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
@RestController
@RequestMapping("/api/v1/accounts")
@RequiredArgsConstructor
@Slf4j
public class AccountController {

    private final AccountService accountService;

    /**
     * API Endpoint thực hiện đăng ký mở tài khoản cơ bản.
     * Xác thực tính toàn vẹn dữ liệu đầu vào trước khi chuyển tiếp cho tầng Service xử lý.
     *
     * @param request đối tượng DTO chứa thông tin đăng ký cơ bản
     * @return ResponseEntity chứa thông tin tài khoản được cấp và mã HTTP 201 Created
     */
    @PostMapping("/register")
    public ResponseEntity<AccountRegisterResponse> registerBasicAccount(
            @Valid @RequestBody AccountRegisterRequest request) {
        log.info("Nhận yêu cầu API POST /api/v1/accounts/register cho SĐT: {}", request.getPhone());
        
        // Gọi tầng nghiệp vụ xử lý đăng ký tài khoản
        AccountRegisterResponse response = accountService.registerBasicAccount(request);
        
        log.info("Hoàn tất xử lý API POST. Cấp tài khoản số: {}", response.getAccountNumber());
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
}
