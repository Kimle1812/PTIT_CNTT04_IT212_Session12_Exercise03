package org.example.session12.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Đối tượng DTO chứa dữ liệu trả về sau khi đăng ký tài khoản thành công.
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountRegisterResponse {

    /**
     * Mã định danh tài khoản duy nhất (định dạng UUID dạng chuỗi).
     */
    private String accountId;

    /**
     * Số tài khoản ngân hàng được cấp tự động.
     */
    private String accountNumber;

    /**
     * Trạng thái hiện tại của tài khoản (PENDING / ACTIVE).
     */
    private String status;
}
