package org.example.session12.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;

/**
 * Lớp xử lý logic kiểm tra tính hợp lệ của Số định danh cá nhân (CCCD) Việt Nam.
 * Áp dụng quy chuẩn CCCD 12 số của Bộ Công An.
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
public class CitizenIdValidator implements ConstraintValidator<CitizenId, String> {

    // Regex kiểm tra chuỗi chỉ chứa đúng 12 chữ số
    private static final Pattern CCCD_PATTERN = Pattern.compile("^\\d{12}$");

    @Override
    public void initialize(CitizenId constraintAnnotation) {
        // Khởi tạo nếu cần
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        // Nếu giá trị rỗng, bỏ qua (đã có @NotBlank xử lý độc lập nếu bắt buộc)
        if (value == null || value.trim().isEmpty()) {
            return true;
        }

        // 1. Kiểm tra độ dài và ký tự số (phải đúng 12 số)
        if (!CCCD_PATTERN.matcher(value).matches()) {
            return false;
        }

        // 2. Phân tích nghiệp vụ sâu hơn về định dạng CCCD Việt Nam:
        // - 3 chữ số đầu: Mã tỉnh/thành phố hoặc mã quốc gia (từ 001 đến 096, hoặc một số mã đặc biệt)
        String provinceCode = value.substring(0, 3);
        int provinceValue = Integer.parseInt(provinceCode);
        if (provinceValue < 1 || provinceValue > 96) {
            // Tùy chỉnh thông báo lỗi động nếu muốn
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Mã tỉnh/thành phố (3 số đầu) trên CCCD không hợp lệ")
                   .addConstraintViolation();
            return false;
        }

        // - Chữ số thứ 4: Mã thế kỷ sinh và giới tính (từ 0 đến 9)
        // 0: Nam (thế kỷ 20 - sinh từ 1900-1999), 1: Nữ (thế kỷ 20)
        // 2: Nam (thế kỷ 21 - sinh từ 2000-2099), 3: Nữ (thế kỷ 21)
        // 4: Nam (thế kỷ 22), 5: Nữ (thế kỷ 22), v.v.
        char genderCenturyChar = value.charAt(3);
        if (genderCenturyChar < '0' || genderCenturyChar > '9') {
            return false;
        }

        // Nếu tất cả kiểm tra đều đạt
        return true;
    }
}
