package org.example.session12.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.session12.validation.CitizenId;

/**
 * Đối tượng DTO chứa thông tin yêu cầu đăng ký mở tài khoản cơ bản.
 * Thực hiện kiểm tra dữ liệu đầu vào bằng các Annotation Validation tiêu chuẩn và Custom Annotation.
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountRegisterRequest {

    /**
     * Họ và tên đầy đủ của khách hàng. Không được để trống.
     */
    @NotBlank(message = "Họ và tên không được để trống")
    private String fullName;

    /**
     * Số điện thoại liên hệ cá nhân. Phải thuộc định dạng số điện thoại Việt Nam hợp lệ.
     */
    @NotBlank(message = "Số điện thoại không được để trống")
    @Pattern(regexp = "^(0|\\+84)[3|5|7|8|9][0-9]{8}$", message = "Số điện thoại không đúng định dạng nhà mạng Việt Nam")
    private String phone;

    /**
     * Địa chỉ Email cá nhân của khách hàng.
     */
    @NotBlank(message = "Email không được để trống")
    @Email(message = "Định dạng Email không hợp lệ")
    private String email;

    /**
     * Số Căn cước công dân (12 chữ số), áp dụng custom validator kiểm tra nghiệp vụ.
     */
    @NotBlank(message = "Số CCCD không được để trống")
    @CitizenId
    private String citizenId;
}
