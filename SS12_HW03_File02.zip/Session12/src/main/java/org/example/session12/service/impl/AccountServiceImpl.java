package org.example.session12.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.session12.dto.AccountRegisterRequest;
import org.example.session12.dto.AccountRegisterResponse;
import org.example.session12.entity.Account;
import org.example.session12.entity.AccountStatus;
import org.example.session12.exception.DuplicateResourceException;
import org.example.session12.repository.AccountRepository;
import org.example.session12.service.AccountService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.security.SecureRandom;

/**
 * Lớp triển khai các nghiệp vụ quản lý tài khoản của ABC Bank.
 * Sử dụng transaction để đảm bảo tính toàn vẹn dữ liệu khi ghi vào database.
 *
 * @author Senior Backend Developer
 * @since 2026-07-01
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final SecureRandom secureRandom = new SecureRandom();

    @Override
    @Transactional
    public AccountRegisterResponse registerBasicAccount(AccountRegisterRequest request) {
        log.info("Bắt đầu xử lý đăng ký tài khoản cơ bản cho khách hàng: {}", request.getFullName());

        // 1. Kiểm tra trùng lặp số điện thoại
        if (accountRepository.existsByPhone(request.getPhone())) {
            log.warn("Đăng ký thất bại: Số điện thoại {} đã tồn tại trên hệ thống", request.getPhone());
            throw new DuplicateResourceException("Số điện thoại này đã được đăng ký sử dụng.");
        }

        // 2. Kiểm tra trùng lặp địa chỉ Email
        if (accountRepository.existsByEmail(request.getEmail())) {
            log.warn("Đăng ký thất bại: Email {} đã tồn tại trên hệ thống", request.getEmail());
            throw new DuplicateResourceException("Địa chỉ email này đã được đăng ký sử dụng.");
        }

        // 3. Kiểm tra trùng lặp Số CCCD
        if (accountRepository.existsByCitizenId(request.getCitizenId())) {
            log.warn("Đăng ký thất bại: Số CCCD {} đã được định danh trên hệ thống", request.getCitizenId());
            throw new DuplicateResourceException("Số CCCD này đã được đăng ký cho một tài khoản khác.");
        }

        // 4. Sinh số tài khoản tự động duy nhất (Dải số tài khoản bắt đầu bằng 999xxxxxxx)
        String accountNumber = generateUniqueAccountNumber();
        log.info("Đã sinh số tài khoản ngẫu nhiên hợp lệ: {}", accountNumber);

        // 5. Khởi tạo đối tượng thực thể Account ở trạng thái PENDING (Chờ eKYC kích hoạt)
        Account account = Account.builder()
                .fullName(request.getFullName())
                .phone(request.getPhone())
                .email(request.getEmail())
                .citizenId(request.getCitizenId())
                .accountNumber(accountNumber)
                .status(AccountStatus.PENDING) // Đăng ký bước đầu mặc định PENDING
                .build();

        // 6. Ghi nhận dữ liệu vào cơ sở dữ liệu
        Account savedAccount = accountRepository.save(account);
        log.info("Lưu tài khoản thành công. ID hệ thống: {}, Account UUID: {}", savedAccount.getId(), savedAccount.getAccountId());

        // 7. Chuyển đổi thông tin thực thể sang DTO trả về cho Client
        return AccountRegisterResponse.builder()
                .accountId(savedAccount.getAccountId())
                .accountNumber(savedAccount.getAccountNumber())
                .status(savedAccount.getStatus().name())
                .build();
    }

    /**
     * Hàm phụ trợ sinh số tài khoản ngân hàng ngẫu nhiên gồm 12 chữ số với đầu số 999.
     * Kiểm tra trùng lặp trong database trước khi trả về.
     */
    private String generateUniqueAccountNumber() {
        String accountNumber;
        boolean exists;
        int maxAttempts = 10;
        int attempts = 0;

        do {
            // Định dạng: 999 + 9 chữ số ngẫu nhiên
            long randomDigits = secureRandom.nextLong(100_000_000L, 999_999_999L);
            accountNumber = "999" + randomDigits;
            exists = accountRepository.existsByAccountNumber(accountNumber);
            attempts++;

            if (attempts > maxAttempts) {
                log.error("Vượt quá số lần thử sinh số tài khoản duy nhất (10 lần)");
                throw new RuntimeException("Lỗi hệ thống khi khởi tạo số tài khoản. Vui lòng thử lại.");
            }
        } while (exists);

        return accountNumber;
    }
}
